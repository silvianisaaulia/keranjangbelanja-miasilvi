export default function Header() {
  return <h1>Catatan Belanjaku 📝</h1>;
}
